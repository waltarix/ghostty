#!/usr/bin/env bash

set -ue

shopt -s extglob

autogen_dir=src/autogen
keep_file=derived_normalization_props.zig

rm -v $autogen_dir/!($keep_file)

zig build gen
